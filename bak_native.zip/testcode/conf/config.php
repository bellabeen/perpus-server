<?php
define("DB_HOST","fdb26.awardspace.net");
define("DB_USER","3074218_latihanarjun");
define("DB_PASSWORD","latihanarjun1");
define("DB_NAME","3074218_latihanarjun");
?>