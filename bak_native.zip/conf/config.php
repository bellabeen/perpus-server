<?php
define("DB_HOST","localhost");
define("DB_USER","bellabeen");
define("DB_PASSWORD","kepoajalu");
define("DB_NAME","ggp");
?>

